<?php
/**
 * License manager.
 *
 * Talks to a placeholder remote endpoint (configurable via STORE_MCP_LICENSE_API).
 * If no license is present, the plugin operates as FREE. Cached for 12h.
 *
 * @package StoreMCP
 */

namespace StoreMCP;

defined( 'ABSPATH' ) || exit;

final class License {

	const TIER_FREE   = 'free';
	const TIER_PRO    = 'pro';
	const TIER_AGENCY = 'agency';

	const STATE_OPTION = 'store_mcp_license_state';
	const KEY_OPTION   = 'store_mcp_license_key';

	public function tier(): string {
		$state = $this->state();
		if ( ! $state || empty( $state['valid'] ) ) {
			return self::TIER_FREE;
		}
		$tier = $state['tier'] ?? self::TIER_FREE;
		return in_array( $tier, [ self::TIER_FREE, self::TIER_PRO, self::TIER_AGENCY ], true ) ? $tier : self::TIER_FREE;
	}

	public function is_pro(): bool {
		return in_array( $this->tier(), [ self::TIER_PRO, self::TIER_AGENCY ], true );
	}

	public function is_agency(): bool {
		return self::TIER_AGENCY === $this->tier();
	}

	public function key(): string {
		return (string) get_option( self::KEY_OPTION, '' );
	}

	public function state(): array {
		$state = get_option( self::STATE_OPTION, [] );
		return is_array( $state ) ? $state : [];
	}

	public function activate( string $license_key ): array {
		$license_key = trim( sanitize_text_field( $license_key ) );
		if ( '' === $license_key ) {
			return [ 'success' => false, 'message' => __( 'License key is empty', 'store-mcp' ) ];
		}
		update_option( self::KEY_OPTION, $license_key, false );
		return $this->verify_remote( true );
	}

	public function deactivate(): array {
		$key = $this->key();
		if ( '' !== $key ) {
			$this->remote_request( 'deactivate', [ 'license_key' => $key ] );
		}
		delete_option( self::KEY_OPTION );
		update_option( self::STATE_OPTION, [
			'valid'      => false,
			'tier'       => self::TIER_FREE,
			'checked_at' => time(),
		], false );
		return [ 'success' => true, 'message' => __( 'License deactivated', 'store-mcp' ) ];
	}

	public function verify_remote( bool $force = false ): array {
		$key = $this->key();
		if ( '' === $key ) {
			$state = [
				'valid'      => false,
				'tier'       => self::TIER_FREE,
				'checked_at' => time(),
				'message'    => __( 'No license configured', 'store-mcp' ),
			];
			update_option( self::STATE_OPTION, $state, false );
			return [ 'success' => true, 'message' => $state['message'], 'tier' => self::TIER_FREE ];
		}

		$response = $this->remote_request( 'verify', [
			'license_key' => $key,
			'site_url'    => home_url(),
		] );

		if ( is_wp_error( $response ) ) {
			$state = $this->state();
			$state['checked_at']  = time();
			$state['last_error']  = $response->get_error_message();
			update_option( self::STATE_OPTION, $state, false );
			return [ 'success' => false, 'message' => $response->get_error_message(), 'tier' => $this->tier() ];
		}

		$state = [
			'valid'        => ! empty( $response['valid'] ),
			'tier'         => isset( $response['tier'] ) ? (string) $response['tier'] : self::TIER_FREE,
			'expires_at'   => isset( $response['expires_at'] ) ? (string) $response['expires_at'] : '',
			'sites_used'   => isset( $response['sites_used'] ) ? (int) $response['sites_used'] : 0,
			'sites_max'    => isset( $response['sites_max'] ) ? (int) $response['sites_max'] : 1,
			'customer'     => isset( $response['customer'] ) ? (string) $response['customer'] : '',
			'checked_at'   => time(),
			'message'      => isset( $response['message'] ) ? (string) $response['message'] : '',
		];

		update_option( self::STATE_OPTION, $state, false );

		return [
			'success' => $state['valid'],
			'message' => $state['message'] ?: ( $state['valid'] ? __( 'License active', 'store-mcp' ) : __( 'License invalid', 'store-mcp' ) ),
			'tier'    => $state['tier'],
		];
	}

	private function remote_request( string $endpoint, array $args ) {
		$url = trailingslashit( STORE_MCP_LICENSE_API ) . $endpoint;

		$response = wp_remote_post( $url, [
			'timeout'   => 15,
			'body'      => wp_json_encode( $args ),
			'headers'   => [
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
				'User-Agent'   => 'StoreMCP/' . STORE_MCP_VERSION . '; ' . home_url(),
			],
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( $code >= 400 ) {
			$message = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : __( 'License server error', 'store-mcp' );
			return new \WP_Error( 'store_mcp_license_http', $message );
		}

		return is_array( $data ) ? $data : [];
	}
}
